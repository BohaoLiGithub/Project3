This is BOHAO LI's project 3 of CSE687. My SUID is 877573155

The test cases execute only in the client whose port number is 8083.

You can get the message and test result in ServerPrototype.exe.

If you have any question about my project, please email me. My email is bli107@syr.edu.
Thank you so much.

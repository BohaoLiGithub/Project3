﻿///////////////////////////////////////////////////////////////////////////////
// CodePopUp.xaml.cs - Displays text file source in response to double-click //
// ver 1.0                                                                   //
// Jim Fawcett, CSE681 - Software Modeling and Analysis, Fall 2017           //
///////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace NavigatorClient
{
  public partial class CodePopUp : Window
  {
    public CodePopUp()
    {
      InitializeComponent();
    }
  }
}
